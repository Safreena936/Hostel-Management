<?php
session_start();

if(!isset($_SESSION['fp_email'])){
    header("location:forgot-password.php");
}

if(isset($_POST['verify'])){
    $otp=$_POST['otp'];

    if($otp==$_SESSION['fp_otp']){
        $_SESSION['otp_verified']=true;
        header("location:reset-password.php");
    }else{
        echo "<script>alert('Invalid OTP');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<title>Verify OTP</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-social.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link rel="stylesheet" href="css/fileinput.min.css">
<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php');?>
<div class="ts-main-content">
<?php include('includes/sidebar.php');?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title">OTP Verification</h2>

<div class="row">
<div class="col-md-6 col-md-offset-3">
<div class="well row pt-2x pb-3x bk-light">
<div class="col-md-8 col-md-offset-2">

<form method="post">
<label class="text-uppercase text-sm">Enter OTP</label>
<input type="text" name="otp" class="form-control mb" placeholder="Enter OTP" required>

<input type="submit" name="verify" class="btn btn-primary btn-block" value="Verify OTP">
</form>

</div>
</div>
</div>
</div>

</div>
</div>
</div>

</body>
</html>


