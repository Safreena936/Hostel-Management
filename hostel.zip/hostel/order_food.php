<?php
session_start();
error_reporting(E_ALL);
include('includes/config.php');
include('includes/checklogin.php');
check_login();

/* ======================
   PLACE FOOD ORDER
====================== */
if(isset($_POST['submit']))
{
    $student_id = $_POST['student_id'];
    $food_id    = $_POST['food_id'];
    $quantity   = $_POST['quantity'];

    // get food price
    $q = $mysqli->prepare("SELECT price FROM food WHERE id=?");
    $q->bind_param("i",$food_id);
    $q->execute();
    $food = $q->get_result()->fetch_assoc();

    $price = $food['price'];
    $total = $price * $quantity;

    // insert order
    $ins = $mysqli->prepare("
        INSERT INTO food_orders
        (student_id, food_id, quantity, total_price, order_date, status)
        VALUES (?,?,?,?,CURDATE(),'Ordered')
    ");
    $ins->bind_param("iiid",$student_id,$food_id,$quantity,$total);
    $ins->execute();

    echo "<script>alert('Food Ordered Successfully');</script>";
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<title>Order Food</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title" style="margin-top: 4%">Order Food</h2>

<div class="panel panel-default">
<div class="panel-heading">Food Order</div>
<div class="panel-body">

<form method="post" class="form-horizontal">

<!-- STUDENT -->
<div class="form-group">
<label class="col-sm-2 control-label">Student</label>
<div class="col-sm-8">
<select name="student_id" class="form-control" required>
<option value="">Select Student</option>
<?php
$s = $mysqli->query("SELECT id, firstName, lastName FROM registration");
while($r = $s->fetch_assoc()){
?>
<option value="<?php echo $r['id']; ?>">
<?php echo $r['firstName']." ".$r['lastName']; ?>
</option>
<?php } ?>
</select>
</div>
</div>

<!-- FOOD -->
<div class="form-group">
<label class="col-sm-2 control-label">Food Item</label>
<div class="col-sm-8">
<select name="food_id" class="form-control" required>
<option value="">Select Food</option>
<?php
$f = $mysqli->query("SELECT id, food_name, price FROM food");
while($row = $f->fetch_assoc()){
?>
<option value="<?php echo $row['id']; ?>">
<?php echo $row['food_name']." - ₹".$row['price']; ?>
</option>
<?php } ?>
</select>
</div>
</div>

<!-- QUANTITY -->
<div class="form-group">
<label class="col-sm-2 control-label">Quantity</label>
<div class="col-sm-8">
<input type="number" name="quantity" class="form-control" value="1" min="1" required>
</div>
</div>

<div class="col-sm-8 col-sm-offset-2">
<input type="submit" name="submit" value="Place Order" class="btn btn-primary">
</div>

</form>

</div>
</div>

</div>
</div>
</div>


<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>
</html>
