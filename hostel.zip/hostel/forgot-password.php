<?php
session_start();
include('includes/config.php');

if(isset($_POST['send'])){
    $emailreg=$_POST['emailreg'];

    $stmt=$mysqli->prepare("SELECT id,email FROM userregistration WHERE email=? OR regNo=?");
    $stmt->bind_param('ss',$emailreg,$emailreg);
    $stmt->execute();
    $stmt->bind_result($id,$email);
    $rs=$stmt->fetch();

    if($rs){
        $otp=rand(100000,999999);
        $_SESSION['fp_email']=$email;
        $_SESSION['fp_otp']=$otp;

        // mail($email,"Password Reset OTP","Your OTP is: $otp");
        echo "<script>alert('OTP : $otp (demo mode)');window.location='verify-otp.php';</script>";
    }else{
        echo "<script>alert('Email / RegNo not found');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<title>Forgot Password</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-social.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link rel="stylesheet" href="css/fileinput.min.css">
<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php');?>
<div class="ts-main-content">
<?php include('includes/sidebar.php');?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title">Forgot Password</h2>

<div class="row">
<div class="col-md-6 col-md-offset-3">
<div class="well row pt-2x pb-3x bk-light">
<div class="col-md-8 col-md-offset-2">

<form method="post">
<label class="text-uppercase text-sm">Email / Registration Number</label>
<input type="text" name="emailreg" class="form-control mb" placeholder="Email / Reg No" required>

<input type="submit" name="send" class="btn btn-primary btn-block" value="Send OTP">
</form>

</div>
</div>
</div>
</div>

</div>
</div>
</div>

</body>
</html>
