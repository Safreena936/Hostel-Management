<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Attendance</title>

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<?php include('includes/header.php'); ?>

<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title" style="margin-top:4%">View Attendance</h2>

<div class="panel panel-default">
<div class="panel-heading">Select Date</div>

<div class="panel-body">

<form method="get" class="form-inline">
    <div class="form-group">
        <input type="date" name="date" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-info">View Attendance</button>
</form>

</div>
</div>

<?php
if (isset($_GET['date'])) {
    $date = $_GET['date'];
?>

<div class="panel panel-default">
<div class="panel-heading">Attendance List (<?php echo $date; ?>)</div>

<div class="panel-body">

<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>S.No</th>
    <th>Student Name</th>
    <th>Status</th>
</tr>
</thead>

<tbody>
<?php
$cnt = 1;
$sql = "SELECT r.firstName, r.lastName, a.status
        FROM attendance a
        JOIN registration r ON r.id = a.student_id
        WHERE a.attendance_date = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
?>
<tr>
    <td><?php echo $cnt++; ?></td>
    <td><?php echo $row['firstName']." ".$row['lastName']; ?></td>
    <td>
        <?php if ($row['status']=="Present") { ?>
            <span class="label label-success">Present</span>
        <?php } else { ?>
            <span class="label label-danger">Absent</span>
        <?php } ?>
    </td>
</tr>
<?php
    }
} else {
?>
<tr>
<td colspan="3" class="text-center text-danger">
    No attendance found for selected date
</td>
</tr>
<?php } $stmt->close(); ?>
</tbody>
</table>

</div>
</div>

<?php } ?>

</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
