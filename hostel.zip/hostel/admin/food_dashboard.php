<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

$month = date('Y-m');

// Total Orders
$q1 = $mysqli->query("SELECT COUNT(id) AS total_orders FROM food_orders");
$tOrders = $q1->fetch_assoc()['total_orders'];

// Total Collection
$q2 = $mysqli->query("SELECT SUM(total_price) AS total_amount FROM food_orders");
$totalAmount = $q2->fetch_assoc()['total_amount'] ?? 0;

// This Month Collection
$q3 = $mysqli->query("
    SELECT SUM(total_price) AS month_amount 
    FROM food_orders 
    WHERE DATE_FORMAT(order_date,'%Y-%m')='$month'
");
$monthAmount = $q3->fetch_assoc()['month_amount'] ?? 0;

// Students Ordered Food
$q4 = $mysqli->query("SELECT COUNT(DISTINCT student_id) AS students FROM food_orders");
$totalStudents = $q4->fetch_assoc()['students'];
?>

<!doctype html>
<html>
<head>
<title>Food Dashboard</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>

<?php include('includes/header.php'); ?>
<?php include('includes/sidebar.php'); ?>

<div class="container">
<h3>Food Bill Dashboard</h3>

<div class="row">

<div class="col-md-3">
<div class="panel panel-primary">
<div class="panel-body text-center">
<h4>Total Orders</h4>
<h2><?= $tOrders ?></h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="panel panel-success">
<div class="panel-body text-center">
<h4>Total Collection</h4>
<h2>₹ <?= $totalAmount ?></h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="panel panel-info">
<div class="panel-body text-center">
<h4>This Month</h4>
<h2>₹ <?= $monthAmount ?></h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="panel panel-warning">
<div class="panel-body text-center">
<h4>Students</h4>
<h2><?= $totalStudents ?></h2>
</div>
</div>
</div>

</div>
</div>

</body>
</html>
