<?php
session_start();
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

include('includes/config.php');
include('includes/checklogin.php');
check_login();

/* =========================
   AJAX : GET REGNO + ROOM + FEES
========================= */
if(isset($_POST['ajax']) && $_POST['ajax']=="getFees"){

    $sid = $_POST['student_id'];

    $stmt = $mysqli->prepare("
        SELECT r.regno, r.roomno, rm.fees
        FROM registration r
        INNER JOIN rooms rm ON rm.room_no = r.roomno
        WHERE r.id = ?
    ");
    $stmt->bind_param("i",$sid);
    $stmt->execute();
    $res = $stmt->get_result();

    if($res->num_rows > 0){
        echo json_encode($res->fetch_assoc());
    }else{
        echo json_encode(["error"=>"Room / Fees not found"]);
    }
    exit;
}

/* =========================
   SAVE FEES (NO MONTH)
========================= */
if(isset($_POST['submit'])){

    $student_id = $_POST['student_id'];
    $roomno     = $_POST['roomno'];
    $fees       = $_POST['fees'];
    $status     = $_POST['status'];
    $paid_date  = ($status=="Paid") ? $_POST['paid_date'] : NULL;

    // already entry check
    $chk = $mysqli->prepare("
        SELECT id FROM student_fees WHERE student_id=?
    ");
    $chk->bind_param("i",$student_id);
    $chk->execute();
    $chk->store_result();

    if($chk->num_rows > 0){
        echo "<script>alert('Fees already entered for this student');</script>";
    }else{

        $ins = $mysqli->prepare("
            INSERT INTO student_fees
            (student_id, room_no, fees, status, paid_date)
            VALUES (?,?,?,?,?)
        ");
        $ins->bind_param(
            "isiss",
            $student_id,
            $roomno,
            $fees,
            $status,
            $paid_date
        );
        $ins->execute();

        echo "<script>alert('Student Fees Added Successfully');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
<meta name="theme-color" content="#3e454c">
<title>Student Fees Entry</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-social.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link rel="stylesheet" href="css/fileinput.min.css">
<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
<link rel="stylesheet" href="css/style.css">

<script src="js/jquery-1.11.3-jquery.min.js"></script>
</head>

<body>
<?php include('includes/header.php'); ?>

<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<div class="row">
<div class="col-md-12">

<h2 class="page-title">Student Fees Entry</h2>

<div class="panel panel-default">
<div class="panel-heading">Add Student Fees</div>

<div class="panel-body">
<form method="post" class="form-horizontal">

<div class="form-group">
<label class="col-sm-2 control-label">Student</label>
<div class="col-sm-8">
<select name="student_id" id="student" class="form-control" required>
<option value="">Select Student</option>
<?php
$q = $mysqli->query("
    SELECT id, firstName, lastName
    FROM registration
    WHERE roomno IS NOT NULL
");
while($row=$q->fetch_assoc()){
?>
<option value="<?php echo $row['id']; ?>">
<?php echo $row['firstName']." ".$row['lastName']; ?>
</option>
<?php } ?>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Register No</label>
<div class="col-sm-8">
<input type="text" id="regno" class="form-control" readonly>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Room No</label>
<div class="col-sm-8">
<input type="text" name="roomno" id="roomno" class="form-control" readonly>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Fees</label>
<div class="col-sm-8">
<input type="text" name="fees" id="fees" class="form-control" readonly>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Status</label>
<div class="col-sm-8">
<select name="status" class="form-control">
<option value="Paid">Paid</option>
<option value="Unpaid">Unpaid</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Paid Date</label>
<div class="col-sm-8">
<input type="date" name="paid_date" class="form-control">
</div>
</div>

<div class="col-sm-8 col-sm-offset-2">
<input class="btn btn-primary" type="submit" name="submit" value="Save Fees">
</div>

</form>
</div>
</div>

</div>
</div>

</div>
</div>
</div>

<script>
$("#student").change(function(){
    var sid = $(this).val();
    $.post("",{ajax:"getFees",student_id:sid},function(res){
        var d = JSON.parse(res);
        if(d.error){
            alert(d.error);
            $("#regno,#roomno,#fees").val('');
        }else{
            $("#regno").val(d.regno);
            $("#roomno").val(d.roomno);
            $("#fees").val(d.fees);
        }
    });
});
</script>

<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
