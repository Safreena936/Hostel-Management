<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/checklogin.php');
check_login();
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
<meta name="theme-color" content="#3e454c">

<title>View Student Fees</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-social.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link rel="stylesheet" href="css/fileinput.min.css">
<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
<link rel="stylesheet" href="css/style.css">

<script src="js/jquery-1.11.3-jquery.min.js"></script>
</head>

<body>
<?php include('includes/header.php'); ?>

<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<div class="row">
<div class="col-md-12">

<h2 class="page-title">View Student Fees</h2>

<div class="panel panel-default">
<div class="panel-heading">Student Fees List</div>

<div class="panel-body">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th>#</th>
<th>Student Name</th>
<th>Register No</th>
<th>Room No</th>
<th>Fees</th>
<th>Status</th>
<th>Paid Date</th>
</tr>
</thead>
<tbody>

<?php
$sql = "
    SELECT sf.*, r.firstName, r.lastName, r.regno
    FROM student_fees sf
    INNER JOIN registration r ON r.id = sf.student_id
    ORDER BY sf.id DESC
";
$query = $mysqli->query($sql);
$cnt = 1;

while($row = $query->fetch_assoc()){
?>
<tr>
<td><?php echo $cnt; ?></td>
<td><?php echo $row['firstName']." ".$row['lastName']; ?></td>
<td><?php echo $row['regno']; ?></td>
<td><?php echo $row['room_no']; ?></td>
<td><?php echo $row['fees']; ?></td>
<td>
<?php if($row['status']=="Paid"){ ?>
<span class="label label-success">Paid</span>
<?php } else { ?>
<span class="label label-danger">Unpaid</span>
<?php } ?>
</td>
<td>
<?php
echo ($row['paid_date']!="") ? $row['paid_date'] : "-";
?>
</td>
</tr>
<?php
$cnt++;
}
?>

</tbody>
</table>
</div>

</div>
</div>
</div>

</div>
</div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/main.js"></script>

<script>
$('.table').DataTable();
</script>

</body>
</html>
