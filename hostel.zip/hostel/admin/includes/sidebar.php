<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
					<li><a href="#"><i class="fa fa-files-o"></i> Courses</a>
					<ul>
						<li><a href="add-courses.php">Add Courses</a></li>
						<li><a href="manage-courses.php">Manage Courses</a></li>
					</ul>
				</li>
					<li><a href="#"><i class="fa fa-desktop"></i> Rooms</a>
					<ul>
						<li><a href="create-room.php">Add a Room</a></li>
						<li><a href="manage-rooms.php">Manage Rooms</a></li>
					</ul>
				</li>
<li><a href="#"><i class="fa fa-check-square"></i> Attendance</a>
					<ul>
						<li><a href="mark_attendence.php">Mark Attendance</a></li>
						<li><a href="view_attendence.php">View Attendance</a></li>

					</ul>
				</li>
				<li><a href="#"><i class="fa fa-desktop"></i> Fees</a>
					<ul>
						<li><a href="student_fees.php"> Add Fees</a></li>
						<li><a href="view_fees.php">View Fees</a></li>
					</ul>
				</li>

				<li><a href="#"><i class="fa fa-desktop"></i> Canteen</a>
					<ul>
						<li><a href="add_food.php"> Add Food</a></li>
						<li><a href="view_food.php">View Food</a></li>
						<li><a href="view_food_orders.php">View Order Food</a></li>
								<li><a href="monthly_food_report.php">Monthly Food Report</a></li>
					</ul>
				</li>


				<li><a href="registration.php"><i class="fa fa-user"></i>Student Registration</a></li>
				<li><a href="manage-students.php"><i class="fa fa-users"></i>Manage Students</a></li>
						<li><a href="#"><i class="fa fa-files-o"></i> Complaints</a>
					<ul>
						<li><a href="new-complaints.php">New</a></li>
						<li><a href="inprocess-complaints.php">In Process</a></li>
						<li><a href="closed-complaints.php">Closed</a></li>
						<li><a href="all-complaints.php">All</a></li>
					</ul>
				</li>
				<li><a href="#"><i class="fa fa-desktop"></i> Feedback</a>
					<ul>
						<li><a href="feedbacks.php">All Feebacks</a></li>
						<!-- <li><a href="feedback-report.php">Feedbacks Report</a></li> -->
					</ul>
				</li>


				<li><a href="access-log.php"><i class="fa fa-file"></i>User Access logs</a></li>

			
		</nav>