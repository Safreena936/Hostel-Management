<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();
// TOTAL FEES (PAID)
$q1 = $mysqli->query("SELECT IFNULL(SUM(fees),0) AS total FROM student_fees WHERE status='Paid'");
$row1 = $q1->fetch_assoc();
$total_fees = $row1['total'];

// PENDING FEES
$q2 = $mysqli->query("SELECT IFNULL(SUM(fees),0) AS total FROM student_fees WHERE status='Unpaid'");
$row2 = $q2->fetch_assoc();
$pending_fees = $row2['total'];

// FOOD INCOME
$q3 = $mysqli->query("SELECT IFNULL(SUM(total_price),0) AS total FROM food_orders");
$row3 = $q3->fetch_assoc();
$food_income = $row3['total'];

// ROOM INCOME
$q4 = $mysqli->query("
SELECT IFNULL(SUM(rm.fees),0) AS total
FROM registration r
JOIN rooms rm ON rm.room_no = r.roomno
");
$row4 = $q4->fetch_assoc();
$room_income = $row4['total'];

// TOTAL HOSTEL INCOME
$total_income = $total_fees + $food_income + $room_income;
?>

?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>DashBoard</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">


</head>

<body>
<?php include("includes/header.php");?>

	<div class="ts-main-content">
		<?php include("includes/sidebar.php");?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h2 class="page-title" style="margin-top:4%">Dashboard</h2>
						
						<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-body bk-primary text-light">
												<div class="stat-panel text-center">

<?php
$result ="SELECT count(*) FROM registration ";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
?>

													<div class="stat-panel-number h1 "><?php echo $count;?></div>
													<div class="stat-panel-title text-uppercase"> Students</div>
												</div>
											</div>
											<a href="manage-students.php" class="block-anchor panel-footer">Full Detail <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-body bk-success text-light">
												<div class="stat-panel text-center">
<?php
$result1 ="SELECT count(*) FROM rooms ";
$stmt1 = $mysqli->prepare($result1);
$stmt1->execute();
$stmt1->bind_result($count1);
$stmt1->fetch();
$stmt1->close();
?>												
													<div class="stat-panel-number h1 "><?php echo $count1;?></div>
													<div class="stat-panel-title text-uppercase">Total Rooms </div>
												</div>
											</div>
											<a href="manage-rooms.php" class="block-anchor panel-footer text-center">See All &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-body bk-info text-light">
												<div class="stat-panel text-center">
<?php
$result2 ="SELECT count(*) FROM courses ";
$stmt2 = $mysqli->prepare($result2);
$stmt2->execute();
$stmt2->bind_result($count2);
$stmt2->fetch();
$stmt2->close();
?>												
													<div class="stat-panel-number h1 "><?php echo $count2;?></div>
													<div class="stat-panel-title text-uppercase">Total Courses</div>
												</div>
											</div>
											<a href="manage-courses.php" class="block-anchor panel-footer text-center">See All &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									
								</div>





				<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-body bk-info text-light">
												<div class="stat-panel text-center">

<?php
$result ="SELECT count(*) FROM complaints ";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();
?>

													<div class="stat-panel-number h1 "><?php echo $count;?></div>
													<div class="stat-panel-title text-uppercase"> Registered Complaints</div>
												</div>
											</div>
											<a href="all-complaints.php" class="block-anchor panel-footer">Full Detail <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-4">
										<div class="panel panel-default">
											<div class="panel-body bk-danger text-light">
												<div class="stat-panel text-center">
<?php
$result2 ="select count(*) from feedback";
$stmt2 = $mysqli->prepare($result2);
$stmt2->execute();
$stmt2->bind_result($count2);
$stmt2->fetch();
$stmt2->close();
?>												
													<div class="stat-panel-number h1 "><?php echo $count2;?></div>
													<div class="stat-panel-title text-uppercase">Total Feedbacks</div>
												</div>
											</div>
											<a href="feedbacks.php" class="block-anchor panel-footer text-center">See All &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									
		<!-- INCOME DASHBOARD ROW 1 -->

<!-- TOTAL FEES -->
<div class="col-md-4">
<div class="panel panel-default">
<div class="panel-body bk-success text-light">
<div class="stat-panel text-center">
<div class="stat-panel-number h1">₹ <?php echo $total_fees; ?></div>
<div class="stat-panel-title text-uppercase">Total Fees Collected</div>
</div>
</div>
<a href="view_fees.php" class="block-anchor panel-footer text-center">See All <i class="fa fa-arrow-right"></i></a>
</div>
</div>

<!-- PENDING FEES -->
<div class="col-md-4">
<div class="panel panel-default">
<div class="panel-body bk-danger text-light">
<div class="stat-panel text-center">
<div class="stat-panel-number h1">₹ <?php echo $pending_fees; ?></div>
<div class="stat-panel-title text-uppercase">Pending Fees</div>
</div>
</div>
<a href="view_fees.php" class="block-anchor panel-footer text-center">See All <i class="fa fa-arrow-right"></i></a>
</div>
</div>

<!-- FOOD INCOME -->
<div class="col-md-4">
<div class="panel panel-default">
<div class="panel-body bk-info text-light">
<div class="stat-panel text-center">
<div class="stat-panel-number h1">₹ <?php echo $food_income; ?></div>
<div class="stat-panel-title text-uppercase">Food Income</div>
</div>
</div>
<a href="view_food_orders.php" class="block-anchor panel-footer text-center">See All <i class="fa fa-arrow-right"></i></a>
</div>
</div>



<!-- ROOM INCOME -->
<div class="col-md-4">
<div class="panel panel-default">
<div class="panel-body bk-primary text-light">
<div class="stat-panel text-center">
<div class="stat-panel-number h1">₹ <?php echo $room_income; ?></div>
<div class="stat-panel-title text-uppercase">Room Income</div>
</div>
</div>
<a href="manage-rooms.php" class="block-anchor panel-footer text-center">See All <i class="fa fa-arrow-right"></i></a>
</div>
</div>

<!-- TOTAL HOSTEL INCOME -->
<div class="col-md-4">
<div class="panel panel-default">
<div class="panel-body bk-success text-light">
<div class="stat-panel text-center">
<div class="stat-panel-number h1">₹ <?php echo $total_income; ?></div>
<div class="stat-panel-title text-uppercase">Total Hostel Income</div>
</div>
</div>
<a href="#" class="block-anchor panel-footer text-center">Overview <i class="fa fa-arrow-right"></i></a>
</div>
</div>
</div>

								</div>
							</div>
						</div>			
						

					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	
	<script>
		
	window.onload = function(){
    
		// Line chart from swirlData for dashReport
		var ctx = document.getElementById("dashReport").getContext("2d");
		window.myLine = new Chart(ctx).Line(swirlData, {
			responsive: true,
			scaleShowVerticalLines: false,
			scaleBeginAtZero : true,
			multiTooltipTemplate: "<%if (label){%><%=label%>: <%}%><%= value %>",
		}); 
		
		// Pie Chart from doughutData
		var doctx = document.getElementById("chart-area3").getContext("2d");
		window.myDoughnut = new Chart(doctx).Pie(doughnutData, {responsive : true});

		// Dougnut Chart from doughnutData
		var doctx = document.getElementById("chart-area4").getContext("2d");
		window.myDoughnut = new Chart(doctx).Doughnut(doughnutData, {responsive : true});

	}
	</script>

</body>

</html>