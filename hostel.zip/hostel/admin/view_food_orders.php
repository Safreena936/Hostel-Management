<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/checklogin.php');
check_login();
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<title>View Food Orders</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title" style="margin-top: 4%">Food Orders</h2>

<div class="panel panel-default">
<div class="panel-heading">View Food Orders</div>
<div class="panel-body">

<table class="table table-bordered table-striped" id="zctb">
<thead>
<tr>
<th>#</th>
<th>Student Name</th>
<th>Food Item</th>
<th>Price</th>
<th>Quantity</th>
<th>Total Price (₹)</th>
<th>Order Date</th>
<th>Status</th>
</tr>
</thead>

<tbody>
<?php
$sql = "
SELECT 
    fo.id,
    r.firstName,
    r.lastName,
    f.food_name,
    f.price,
    fo.quantity,
    fo.total_price,
    fo.order_date,
    fo.status
FROM food_orders fo
JOIN registration r ON r.id = fo.student_id
JOIN food f ON f.id = fo.food_id
ORDER BY fo.id DESC
";

$query = $mysqli->query($sql);
$cnt = 1;

while($row = $query->fetch_assoc()){
?>
<tr>
<td><?php echo $cnt; ?></td>
<td><?php echo $row['firstName']." ".$row['lastName']; ?></td>
<td><?php echo $row['food_name']; ?></td>
<td>₹<?php echo $row['price']; ?></td>
<td><?php echo $row['quantity']; ?></td>
<td>₹<?php echo $row['total_price']; ?></td>
<td><?php echo $row['order_date']; ?></td>
<td>
<span class="label label-success">
<?php echo $row['status']; ?>
</span>
</td>
</tr>
<?php
$cnt++;
}
?>
</tbody>
</table>

</div>
</div>

</div>
</div>
</div>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

<script>
$(document).ready(function() {
    $('#zctb').DataTable();
});
</script>

</body>
</html>
