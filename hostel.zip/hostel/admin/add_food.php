<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/checklogin.php');
check_login();

if(isset($_POST['submit']))
{
    $food  = $_POST['food'];
    $price = $_POST['price'];
    $type  = $_POST['type'];

    // check food already exists
    $sql = "SELECT food_name FROM food WHERE food_name=?";
    $stmt1 = $mysqli->prepare($sql);
    $stmt1->bind_param('s',$food);
    $stmt1->execute();
    $stmt1->store_result();

    if($stmt1->num_rows > 0)
    {
        echo "<script>alert('Food already exists');</script>";
    }
    else
    {
        $query = "INSERT INTO food (food_name, price, type) VALUES (?,?,?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sis',$food,$price,$type);
        $stmt->execute();

        echo "<script>alert('Food Added Successfully');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Food</title>

	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="js/jquery-1.11.3-jquery.min.js"></script>
</head>

<body>
<?php include('includes/header.php');?>
<div class="ts-main-content">
<?php include('includes/sidebar.php');?>
<div class="content-wrapper">
<div class="container-fluid">

<div class="row">
<div class="col-md-12">
<h2 class="page-title" style="margin-top: 4%">Add Food</h2>

<div class="panel panel-default">
<div class="panel-heading">Add Food Item</div>
<div class="panel-body">

<form method="post" class="form-horizontal">

<div class="form-group">
<label class="col-sm-2 control-label">Food Name</label>
<div class="col-sm-8">
<input type="text" name="food" class="form-control" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Price (₹)</label>
<div class="col-sm-8">
<input type="number" name="price" class="form-control" required>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Food Type</label>
<div class="col-sm-8">
<select name="type" class="form-control" required>
<option value="">Select Type</option>
<option value="Veg">Veg</option>
<option value="Non-Veg">Non-Veg</option>
</select>
</div>
</div>

<div class="col-sm-8 col-sm-offset-2">
<input class="btn btn-primary" type="submit" name="submit" value="Add Food">
</div>

</form>

</div>
</div>
</div>
</div>

</div>
</div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
