<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

$month = date('m');
$year  = date('Y');

if(isset($_GET['month'])){
    $month = $_GET['month'];
}
if(isset($_GET['year'])){
    $year = $_GET['year'];
}

/* ===== SUMMARY DATA ===== */

// Total Orders
$q1 = $mysqli->prepare("
    SELECT COUNT(*) 
    FROM food_orders 
    WHERE MONTH(order_date)=? AND YEAR(order_date)=?
");
$q1->bind_param("ii",$month,$year);
$q1->execute();
$q1->bind_result($total_orders);
$q1->fetch();
$q1->close();

// Total Expense
$q2 = $mysqli->prepare("
    SELECT IFNULL(SUM(total_price),0) 
    FROM food_orders 
    WHERE MONTH(order_date)=? AND YEAR(order_date)=?
");
$q2->bind_param("ii",$month,$year);
$q2->execute();
$q2->bind_result($total_expense);
$q2->fetch();
$q2->close();

// Total Quantity
$q3 = $mysqli->prepare("
    SELECT IFNULL(SUM(quantity),0) 
    FROM food_orders 
    WHERE MONTH(order_date)=? AND YEAR(order_date)=?
");
$q3->bind_param("ii",$month,$year);
$q3->execute();
$q3->bind_result($total_qty);
$q3->fetch();
$q3->close();

/* ===== FOOD WASTE LOGIC (ESTIMATION) =====
   Example logic:
   Assume 10% of total quantity = waste
*/
$food_waste_qty = round($total_qty * 0.10);
$food_waste_cost = round($total_expense * 0.10);

?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<title>Monthly Food Report</title>

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php'); ?>

<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title" style="margin-top: 4%">Monthly Food Report</h2>

<!-- FILTER -->
<form method="get" class="row" style="margin-bottom:20px;">
    <div class="col-md-3">
        <select name="month" class="form-control">
            <?php
            for($m=1;$m<=12;$m++){
                $sel = ($m==$month)?"selected":"";
                echo "<option value='$m' $sel>".date("F", mktime(0,0,0,$m,1))."</option>";
            }
            ?>
        </select>
    </div>
    <div class="col-md-3">
        <select name="year" class="form-control">
            <?php
            for($y=2023;$y<=2035;$y++){
                $sel = ($y==$year)?"selected":"";
                echo "<option value='$y' $sel>$y</option>";
            }
            ?>
        </select>
    </div>
    <div class="col-md-2">
        <button class="btn btn-primary">View</button>
    </div>
</form>

<!-- SUMMARY CARDS -->
<div class="row">

<div class="col-md-3">
<div class="panel panel-default">
<div class="panel-body bk-primary text-light text-center">
<h4>Total Orders</h4>
<h3><?php echo $total_orders; ?></h3>
</div>
</div>
</div>

<div class="col-md-3">
<div class="panel panel-default">
<div class="panel-body bk-success text-light text-center">
<h4>Total Expense</h4>
<h3>₹ <?php echo $total_expense; ?></h3>
</div>
</div>
</div>

<div class="col-md-3">
<div class="panel panel-default">
<div class="panel-body bk-info text-light text-center">
<h4>Total Quantity</h4>
<h3><?php echo $total_qty; ?></h3>
</div>
</div>
</div>

<div class="col-md-3">
<div class="panel panel-default">
<div class="panel-body bk-danger text-light text-center">
<h4>Estimated Waste</h4>
<h3><?php echo $food_waste_qty; ?> items ₹ <?php echo $food_waste_cost; ?></h3>
</div>
</div>
</div>

</div>

<!-- TABLE -->
<div class="panel panel-default">
<div class="panel-heading">Monthly Food Orders</div>
<div class="panel-body">

<table class="table table-bordered">
<thead>
<tr>
<th>#</th>
<th>Student</th>
<th>Food</th>
<th>Qty</th>
<th>Total Price</th>
<th>Date</th>
<th>Status</th>
</tr>
</thead>
<tbody>

<?php
$sql = "
SELECT fo.*, 
       r.firstName, r.lastName,
       f.food_name
FROM food_orders fo
JOIN registration r ON r.id = fo.student_id
JOIN food f ON f.id = fo.food_id
WHERE MONTH(fo.order_date)=? AND YEAR(fo.order_date)=?
ORDER BY fo.id DESC
";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("ii",$month,$year);
$stmt->execute();
$res = $stmt->get_result();

$i=1;
while($row = $res->fetch_assoc()){
?>
<tr>
<td><?php echo $i++; ?></td>
<td><?php echo $row['firstName']." ".$row['lastName']; ?></td>
<td><?php echo $row['food_name']; ?></td>
<td><?php echo $row['quantity']; ?></td>
<td>₹ <?php echo $row['total_price']; ?></td>
<td><?php echo $row['order_date']; ?></td>
<td><?php echo $row['status']; ?></td>
</tr>
<?php } ?>

</tbody>
</table>

</div>
</div>

</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>
</html>
