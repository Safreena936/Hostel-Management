<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

if (isset($_POST['submit'])) {

    $date = $_POST['attdate'];
    $time = date("H:i:s"); // current time

    foreach ($_POST['status'] as $sid => $status) {

        $reason = NULL;
        if ($status == "Absent") {
            $reason = $_POST['reason'][$sid];
        }

        // check duplicate
        $checkSql = "SELECT id FROM attendance WHERE student_id=? AND attendance_date=?";
        $stmtCheck = $mysqli->prepare($checkSql);
        $stmtCheck->bind_param("is", $sid, $date);
        $stmtCheck->execute();
        $stmtCheck->store_result();

        if ($stmtCheck->num_rows == 0) {

            $insertSql = "INSERT INTO attendance
            (student_id, attendance_date, attendance_time, status, reason)
            VALUES (?,?,?,?,?)";

            $stmtInsert = $mysqli->prepare($insertSql);
            $stmtInsert->bind_param(
                "issss",
                $sid,
                $date,
                $time,
                $status,
                $reason
            );
            $stmtInsert->execute();
            $stmtInsert->close();
        }
        $stmtCheck->close();
    }

    echo "<script>alert('Attendance Marked Successfully');</script>";
}
?>
<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
<title>Mark Attendance</title>
<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>

<script>
function toggleReason(id){
    var status = document.getElementById("status_"+id).value;
    var reasonBox = document.getElementById("reason_"+id);

    if(status === "Absent"){
        reasonBox.style.display = "block";
        reasonBox.required = true;
    }else{
        reasonBox.style.display = "none";
        reasonBox.required = false;
    }
}
</script>
</head>

<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title">Mark Attendance</h2>

<div class="panel panel-default">
<div class="panel-heading">Attendance Sheet</div>

<div class="panel-body">
<form method="post">

<input type="date" name="attdate" class="form-control" required>
<br>

<table class="table table-bordered">
<thead>
<tr>
    <th>S.No</th>
    <th>Student Name</th>
    <th>Status</th>
    <th>Absent Reason</th>
</tr>
</thead>

<tbody>
<?php
$cnt=1;
$sql="SELECT id, firstName, lastName FROM registration";
$stmt=$mysqli->prepare($sql);
$stmt->execute();
$result=$stmt->get_result();

while($row=$result->fetch_assoc()){
?>
<tr>
<td><?php echo $cnt++; ?></td>

<td><?php echo $row['firstName']." ".$row['lastName']; ?></td>

<td>
<select name="status[<?php echo $row['id']; ?>]"
        id="status_<?php echo $row['id']; ?>"
        class="form-control"
        onchange="toggleReason(<?php echo $row['id']; ?>)">
    <option value="Present">Present</option>
    <option value="Absent">Absent</option>
</select>
</td>

<td>
<input type="text"
       name="reason[<?php echo $row['id']; ?>]"
       id="reason_<?php echo $row['id']; ?>"
       class="form-control"
       placeholder="Enter absent reason"
       style="display:none;">
</td>
</tr>
<?php } $stmt->close(); ?>
</tbody>
</table>

<button type="submit" name="submit" class="btn btn-primary">
Save Attendance
</button>

</form>
</div>
</div>

</div>
</div>
</div>
<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>
</html>
