<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/checklogin.php');
check_login();
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>View Food</title>

	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php');?>
<div class="ts-main-content">
<?php include('includes/sidebar.php');?>
<div class="content-wrapper">
<div class="container-fluid">

<div class="row">
<div class="col-md-12">
<h2 class="page-title" style="margin-top: 4%">View Food Items</h2>

<div class="panel panel-default">
<div class="panel-heading">Food List</div>
<div class="panel-body">

<table class="table table-striped table-bordered table-hover" id="zctb">
<thead>
<tr>
	<th>#</th>
	<th>Food Name</th>
	<th>Price (₹)</th>
	<th>Type</th>
	<th>Created Date</th>
</tr>
</thead>

<tbody>
<?php
$sql = "SELECT * FROM food ORDER BY id DESC";
$query = $mysqli->prepare($sql);
$query->execute();
$res = $query->get_result();
$cnt = 1;

while($row = $res->fetch_assoc())
{
?>
<tr>
	<td><?php echo $cnt; ?></td>
	<td><?php echo htmlentities($row['food_name']); ?></td>
	<td><?php echo htmlentities($row['price']); ?></td>
	<td><?php echo htmlentities($row['type']); ?></td>
	<td><?php echo htmlentities($row['created_at'] ?? '-'); ?></td>
</tr>
<?php
$cnt++;
}
?>
</tbody>
</table>

</div>
</div>
</div>
</div>

</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/main.js"></script>

<script>
$(document).ready(function() {
    $('#zctb').DataTable();
});
</script>

</body>
</html>
