<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
<title>View Attendance</title>
<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>

<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title">View Attendance</h2>

<!-- DATE FILTER -->
<div class="panel panel-default">
<div class="panel-heading">Select Date</div>
<div class="panel-body">

<form method="get" class="form-inline">
    <input type="date" name="date" class="form-control" required>
    <button type="submit" class="btn btn-info">View Attendance</button>
</form>

</div>
</div>

<?php
if(isset($_GET['date'])){
    $date = $_GET['date'];
?>

<!-- ATTENDANCE LIST -->
<div class="panel panel-default">
<div class="panel-heading">
Attendance Details (<?php echo $date; ?>)
</div>

<div class="panel-body">

<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>S.No</th>
    <th>Student Name</th>
    <th>Time</th>
    <th>Status</th>
    <th>Absent Reason</th>
</tr>
</thead>

<tbody>
<?php
$cnt = 1;

$sql = "SELECT 
            r.firstName, 
            r.lastName,
            a.attendance_time,
            a.status,
            a.reason
        FROM attendance a
        JOIN registration r ON r.id = a.student_id
        WHERE a.attendance_date = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
?>
<tr>
<td><?php echo $cnt++; ?></td>

<td><?php echo $row['firstName']." ".$row['lastName']; ?></td>

<td><?php echo $row['attendance_time']; ?></td>

<td>
<?php if($row['status']=="Present"){ ?>
    <span class="label label-success">Present</span>
<?php } else { ?>
    <span class="label label-danger">Absent</span>
<?php } ?>
</td>

<td>
<?php
if($row['status']=="Absent"){
    echo $row['reason'];
}else{
    echo "-";
}
?>
</td>
</tr>
<?php
    }
}else{
?>
<tr>
<td colspan="5" class="text-center text-danger">
    No attendance found for selected date
</td>
</tr>
<?php }
$stmt->close();
?>
</tbody>
</table>

</div>
</div>

<?php } ?>

</div>
</div>
</div>
<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
</html>
