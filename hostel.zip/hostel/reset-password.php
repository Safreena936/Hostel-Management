<?php
session_start();
include('includes/config.php');

if(!isset($_SESSION['otp_verified'])){
    header("location:forgot-password.php");
}

if(isset($_POST['reset'])){
    $new=$_POST['new_password'];
    $confirm=$_POST['confirm_password'];

    if($new==$confirm){
        $hash=password_hash($new,PASSWORD_BCRYPT);
        $email=$_SESSION['fp_email'];

        $stmt=$mysqli->prepare("UPDATE userregistration SET password=? WHERE email=?");
        $stmt->bind_param('ss',$hash,$email);
        $stmt->execute();

        session_destroy();
        echo "<script>alert('Password Reset Successfully');window.location='index.php';</script>";
    }else{
        echo "<script>alert('Password mismatch');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<title>Reset Password</title>

<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-social.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link rel="stylesheet" href="css/fileinput.min.css">
<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php');?>
<div class="ts-main-content">
<?php include('includes/sidebar.php');?>

<div class="content-wrapper">
<div class="container-fluid">

<h2 class="page-title">Reset Password</h2>

<div class="row">
<div class="col-md-6 col-md-offset-3">
<div class="well row pt-2x pb-3x bk-light">
<div class="col-md-8 col-md-offset-2">

<form method="post">
<label class="text-uppercase text-sm">New Password</label>
<input type="password" name="new_password" class="form-control mb" placeholder="New Password" required>

<label class="text-uppercase text-sm">Confirm Password</label>
<input type="password" name="confirm_password" class="form-control mb" placeholder="Confirm Password" required>

<input type="submit" name="reset" class="btn btn-primary btn-block" value="Reset Password">
</form>

</div>
</div>
</div>
</div>

</div>
</div>
</div>

</body>
</html>
